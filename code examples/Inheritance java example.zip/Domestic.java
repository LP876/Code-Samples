
public class Domestic extends Commercial {
protected double airportFee;


public Domestic (String departLocation,String destination, Time departTime, Time duration, double securityFee, double af){
	super(departLocation,destination, departTime, duration, securityFee);
	airportFee= af;
    flightNumber+="-D";
}
//Domestic d1 = new Domestic("Vancouver", "Victoria", new Time(10,11), new Time(0,35), 15.00, 10.00);
	//Accessor method
		public double getairportFee() { return airportFee; }
		//new Domestic("Vancouver", "Victoria", new Time(10,11), new Time(0,35), 15.00, 10.00);	
		//Mutator Method
		//public void setairportFee(double af) { airportFee = af; }
		 public void setDepartTime(Time t) { departTime = t; }
		   public void setDuration(Time t) { duration = t; }

		public String toString() {
		    return super.toString(); //+airportFee 
}

}