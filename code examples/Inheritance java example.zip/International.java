
public class International extends Commercial {
protected String country;


public International (String departLocation,String destination, Time departTime, Time duration, double securityFee, String cn){
	super(departLocation, destination, departTime, duration, securityFee);
	this.country= cn;

	 flightNumber +="-I";
}	
//International i1 = new International("Vancouver", "Las Vegas", new Time(17,0), new Time(2,45), 15.00, "United States");
	//Accessor method
		public String getcountry() { return country; }
		
		//Mutator Method
		//public void setairportFee(String cn) { country = cn; }
		 public void setDepartTime(Time t) { departTime = t; }
		   public void setDuration(Time t) { duration = t; }
	      
		   public void setCountry( String c) { country = c; }
	
		   @Override
		   public String toString() {
		    return super.toString() + "\n" + "Country: " + country + "\n";
}

}

