
public class Cargo extends Flight {
private String freightDescription;

public Cargo (String departLocation,String destination, Time departTime, Time duration,String freightDescription){
	super(departLocation,destination, departTime, duration);
	this.freightDescription= freightDescription;
	 flightNumber+="-C";
}

//Accessor method
public String getFreightDescription() { return freightDescription; }

//Mutator Method
public void setDepartTime(Time t) { departTime = t; }
public void setDuration(Time t) { duration = t; }

public String toString() {
    return super.toString() + freightDescription ;
}
}