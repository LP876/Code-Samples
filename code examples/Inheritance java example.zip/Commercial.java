
public class Commercial extends Flight {
protected String status;
public double securityFee;

public Commercial (String departLocation,String destination, Time departTime, Time duration, double securityFee){
	super(departLocation,destination, departTime, duration);
	this.status= " On Time";
	this.securityFee= securityFee;
	flightNumber +="-C";
}

	//Accessor method
	public String getStatus() { return status; }
	
	//Accessor method
	public double getsecurityFee() { return securityFee; }
	
	//Mutator Method
	 
    public void setStatus(String s) { this.status = s; }

	//public void setStatus(String st) { status = st; }

	//Mutator Method
	public void setsecurityFee(double sf) { securityFee = sf; }
 @Override
	public String toString() {
	    return super.toString() + "Status: " + status + " Security Fee: " +securityFee ;
}
}