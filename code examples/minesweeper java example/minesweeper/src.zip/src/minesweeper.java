import java.util.*;
import java.io.*;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
public class minesweeper extends Application {
	public static void main (String[]args) {
		launch(args);
	}
	@Override
	public void start(Stage theStage) {
		GridPane pane = new GridPane();
		
		BorderPane bp = new BorderPane();
		smileyface sf = new smileyface();
		bt tiles [][]  = new bt [5][5];
		int field [][] = new int [5][5];
		 field = buildGrid(field);
		 String ct = "  003   ";
		 Label lct = new Label(ct);
		 lct.setFont(new Font("Times New Roman",30));
		 Label t = new Label("   000");
		 t.setFont(new Font ("Times New Roman", 30));
		 HBox top = new HBox ();
		 ArrayList<Integer> alic = new ArrayList <Integer>();
			for (int i = 0; i <5; i++) {
				for(int j = 0; j < 5; j++) {
					tiles [i][j]= new bt();
					bt tb = tiles[i][j];
					tb.lb = field[i][j];
						tb.setOnAction(e -> {

								switch(tb.lb) {
								case 0: 
									tb.setGraphic(tb.lp00);
									alic.add(0);
									if(alic.size()== 22) {
										sf.setGraphic(sf.fshades);
									}
									break;
								
								case 1:
									tb.setGraphic(tb.lp01);
									alic.add(1);
									if(alic.size()== 22) {
										sf.setGraphic(sf.fshades);
									}
									break;
								
								case 2:
									tb.setGraphic(tb.lp02);
									alic.add(2);
									if(alic.size()== 22) {
										sf.setGraphic(sf.fshades);
									}
								break;
								
								case 3:
									tb.setGraphic(tb.lp03);
									alic.add(3);
									if(alic.size()== 22) {
										sf.setGraphic(sf.fshades);
									}
									break;
								
								case 4: 
									tb.setGraphic(tb.dimine);
									sf.setGraphic(sf.fdead);
									alic.removeAll(alic);
									break;
								
								}
						});
					pane.add(tb,i, j);
				}

			}
		top.getChildren().addAll(lct, sf, t);
		bp.setTop(top);
		bp.setCenter(pane);
		theStage.setTitle("Minesweeper");
		theStage.setScene(new Scene(bp));
		theStage.show();
		}
	public int [][] buildGrid ( int [][]field) {
		field [0][0]= 1;
		field [0][1]= 2;
		field [0][2]= 2;
		field [0][3]= 1;
		field [0][4]= 0;
		field [1][0]= 3;
		field [1][1]= 1;
		field [1][2]= 0;
		field [1][3]= 0;
		field [1][4]= 1;
		field [2][0]= 1;
		field [2][1]= 3;
		field [2][2]= 4;
		field [2][3]= 1;
		field [2][4]= 2;
		field [3][0]= 0;
		field [3][1]= 1;
		field [3][2]= 3;
		field [3][3]= 2;
		field [3][4]= 2;
		field [4][0]= 1;
		field [4][1]= 1;
		field [4][2]= 3;
		field [4][3]= 3;
		field [4][4]= 2;
		
	return field;
		
	}
	
}
